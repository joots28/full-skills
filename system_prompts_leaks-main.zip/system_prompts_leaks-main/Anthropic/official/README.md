# Official Claude system prompts

Archives from https://platform.claude.com/docs/en/release-notes/system-prompts — the `claude_behavior` system prompts Anthropic publishes for claude.ai and the mobile apps. Files are named by the date Anthropic labels each prompt version. [all.md](all.md) holds every version in one file.

| Model | Model release date | Archived prompt versions |
|-------|--------------------|--------------------------|
| **Claude Haiku 5.5** | October 7, 2026 | [October 7, 2026](2026-10-07-claude-haiku-5.5.md) |
| **Claude Sonnet 5.5** | September 28, 2026 | [September 28, 2026](2026-09-28-claude-sonnet-5.5.md) |
| **Claude Opus 5.5** | September 22, 2026 | [September 22, 2026](2026-09-22-claude-opus-5.5.md) |
| **Claude Fable 5.1** | September 1, 2026 | [September 1, 2026](2026-09-01-claude-fable-5.1.md) |
| **Claude Opus 5** | July 24, 2026 | [July 24, 2026](2026-07-24-claude-opus-5.md) |
| **Claude Sonnet 5** | June 30, 2026 | [June 30, 2026](2026-06-30-claude-sonnet-5.md) |
| **Claude Fable 5** | June 9, 2026 | [June 9, 2026](2026-06-09-claude-fable-5.md) |
| **Claude Opus 4.8** | May 28, 2026 | [May 28, 2026](2026-05-28-claude-opus-4.8.md) |
| Claude Opus 4.7 | April 16, 2026 | [April 16, 2026](2026-04-16-claude-opus-4.7.md) |
| Claude Sonnet 4.6 | February 17, 2026 | [February 17, 2026](2026-02-17-claude-sonnet-4.6.md) |
| Claude Opus 4.6 | February 5, 2026 | [February 5, 2026](2026-02-05-claude-opus-4.6.md) |
| Claude Opus 4.5 | November 24, 2025 | [November 24, 2025](2025-11-24-claude-opus-4.5.md) · [January 18, 2026](2026-01-18-claude-opus-4.5.md) |
| Claude Haiku 4.5 | October 15, 2025 | [October 15, 2025](2025-10-15-claude-haiku-4.5.md) · [November 19, 2025](2025-11-19-claude-haiku-4.5.md) · [January 18, 2026](2026-01-18-claude-haiku-4.5.md) |
| Claude Sonnet 4.5 | September 29, 2025 | [September 29, 2025](2025-09-29-claude-sonnet-4.5.md) · [November 19, 2025](2025-11-19-claude-sonnet-4.5.md) · [January 18, 2026](2026-01-18-claude-sonnet-4.5.md) |
| Claude Opus 4.1 | August 5, 2025 | [August 5, 2025](2025-08-05-claude-opus-4.1.md) |
| Claude Opus 4 | May 22, 2025 | [May 22, 2025](2025-05-22-claude-opus-4.md) · [July 31, 2025](2025-07-31-claude-opus-4.md) · [August 5, 2025](2025-08-05-claude-opus-4.md) |
| Claude Sonnet 4 | May 22, 2025 | [May 22, 2025](2025-05-22-claude-sonnet-4.md) · [July 31, 2025](2025-07-31-claude-sonnet-4.md) · [August 5, 2025](2025-08-05-claude-sonnet-4.md) |
| Claude Sonnet 3.7 | February 24, 2025 | [February 24, 2025](2025-02-24-claude-sonnet-3.7.md) |
| Claude Sonnet 3.5 | June 20, 2024 | [July 12, 2024](2024-07-12-claude-sonnet-3.5-text-and-images.md) · [September 9, 2024](2024-09-09-claude-sonnet-3.5-text-and-images.md) ([text only](2024-09-09-claude-sonnet-3.5-text-only.md)) · [October 22, 2024](2024-10-22-claude-sonnet-3.5-text-and-images.md) ([text only](2024-10-22-claude-sonnet-3.5-text-only.md)) · [November 22, 2024](2024-11-22-claude-sonnet-3.5-text-and-images.md) ([text only](2024-11-22-claude-sonnet-3.5-text-only.md)) |
| Claude Haiku 3.5 | October 22, 2024 | [October 22, 2024 (text only)](2024-10-22-claude-haiku-3.5-text-only.md) · [February 24, 2025](2025-02-24-claude-haiku-3.5-text-and-images.md) |
| Claude Opus 3 | March 4, 2024 | [July 12, 2024](2024-07-12-claude-opus-3.md) |
| Claude Haiku 3 | March 4, 2024 | [July 12, 2024](2024-07-12-claude-haiku-3.md) |

## Publication timing

Anthropic dates each entry to the model's release day. Continuous page monitoring (since May 2026) tracks when entries actually appear:

- **Claude Opus 4.8** — entry labeled May 28, 2026; actually published June 4, 2026 (7 days after release)
- **Claude Fable 5** — entry labeled June 9, 2026; actually published overnight June 12–13, 2026 (3–4 days after release)
- **Claude Opus 5** — entry labeled July 24, 2026; published July 24, 2026 (same day)
- **Claude Fable 5.1** — entry labeled September 1, 2026; published September 1, 2026 (same day)
- **Claude Opus 5.5** — entry labeled September 22, 2026; published September 22, 2026 (same day)
- **Claude Sonnet 5** — entry labeled June 30, 2026; actually published September 28, 2026 (90 days after release)
- **Claude Sonnet 5.5** — entry labeled September 28, 2026; published September 28, 2026 (same day)
- **Claude Haiku 5.5** — entry labeled October 7, 2026; published October 7, 2026 (same day)

Entries older than the monitoring have unknown actual publication dates.

## Claude's constitution

Anthropic's published constitution, the document describing Claude's values and character. Not a system prompt, archived here as an official publication.

| Version | Published | File |
|---------|-----------|------|
| v2 | January 20, 2026 | [claude-constitution-v2.md](claude-constitution/2026-01-20-claude-constitution-v2.md) |
| v1 | May 9, 2023 | [claude-constitution-v1.md](claude-constitution/2023-05-09-claude-constitution-v1.md) |

## Usage Policy

Every version of Anthropic's Usage Policy (Acceptable Use Policy), text only so versions diff cleanly. Index in [anthropic-usage-policies/README.md](anthropic-usage-policies/README.md).
